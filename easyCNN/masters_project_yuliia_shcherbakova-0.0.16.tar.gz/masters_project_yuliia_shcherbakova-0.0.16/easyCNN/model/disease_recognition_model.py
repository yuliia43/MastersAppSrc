import tensorflow as tf
from tensorflow.keras import layers, regularizers
from tensorflow import keras

class DiseaseRecognitionModel(tf.keras.Sequential):

    def __init__(self, img_height, img_width, cnn_args: list, dense_args: list, num_classes, trainable=True,
                 name="DiseaseRecognitionModel"):
        """:param cnn_args: list containing the parameters for cnn inputs in format (filters, kernel_size, dropout_rate).
         Cnn layer size will depend on its size"""

        rescaling = keras.layers.Rescaling(1. / 255, input_shape=(img_height, img_width, 3), trainable=trainable)
        data_augmentation = DataAugmentationLayer(trainable=trainable)
        cnn_layers = [ConvolutionLayer(cnn_arg[0], cnn_arg[1], cnn_arg[2], trainable=trainable)
                                          for cnn_arg in cnn_args]
        cnn_flatten = keras.layers.Flatten(trainable=trainable)

        dense_layers = [DenseWithNormalization(dense_arg[0], dense_arg[1], dense_arg[2], dense_arg[3],
                                               trainable=trainable) for dense_arg in dense_args]
        classifier = keras.layers.Dense(num_classes, trainable=trainable)

        model_layers = [rescaling, data_augmentation] + cnn_layers + [cnn_flatten] + dense_layers + [classifier]

        super(DiseaseRecognitionModel, self).__init__(name=name, layers=model_layers)

        self.img_height = img_height
        self.img_width = img_width
        self.cnn_args = cnn_args
        self.dense_args = dense_args
        self.num_classes = num_classes
    #
        # self.rescaling = rescaling
        # self.data_augmentation = data_augmentation
    #     self.cnn = cnn
    #     self.cnn_flatten = cnn_flatten
    #     self.dense_layers = dense_layers
    #     self.classifier = classifier
    #
    #     self.trainable = trainable
    #
    # def call(self, inputs):
    #     x = self.rescaling(inputs)
    #     x = self.data_augmentation(x)
    #     x = self.cnn(x)
    #     x = self.cnn_flatten(x)
    #     x = self.dense_layers(x)
    #     return self.classifier(x)

    def get_config(self):
        config = super(DiseaseRecognitionModel, self).get_config()
        config.update({"img_height": self.img_height,
                       "img_width": self.img_width,
                       "cnn_args": self.cnn_args,
                       "dense_args": self.dense_args,
                       "num_classes": self.num_classes,
                       "name": self.name})
        return config

    @classmethod
    def from_config(cls, config):
        params = ["img_height", "img_width", "cnn_args", "dense_args", "num_classes", "trainable",
                 "name"]
        config_filtered = {key: value for key, value in config.items() if key in params}
        return cls(**config_filtered)

    def save_model_into_file(self, filepath):
        json_string = self.to_json()
        with open(filepath, "w") as json_file:
            json_file.write(json_string)


class DataAugmentationLayer(tf.keras.Sequential):

    def __init__(self, trainable=True, name="DataAugmentationLayer"):
        data_augmentation = [
            layers.RandomFlip("horizontal", trainable=trainable),
            layers.RandomRotation(0.05, trainable=trainable),
            layers.RandomCrop(190, 190, seed=123, trainable=trainable),
            layers.RandomZoom((-0.1, 0.1), trainable=trainable),
            layers.RandomContrast(0.3, trainable=trainable)
        ]
        super(DataAugmentationLayer, self).__init__(name=name, layers=data_augmentation)

    @classmethod
    def from_config(cls, config):
        params = ["trainable", "name"]
        config_filtered = {key: value for key, value in config.items() if key in params}
        return cls(**config_filtered)


class ConvolutionLayer(tf.keras.Sequential):

    def __init__(self, filters, kernel_size, dropout_rate=None, trainable=True, name=None):
        conv2d = layers.Conv2D(filters=filters, kernel_size=kernel_size, padding='same', activation='relu', trainable=trainable)
        max_pooling = layers.MaxPooling2D(trainable=trainable)
        batch_normalization = layers.BatchNormalization(trainable=trainable)

        inner_layers = [conv2d, max_pooling, batch_normalization]

        dropout_layer = None
        if dropout_rate is not None:
            dropout_layer = layers.SpatialDropout2D(dropout_rate)
            inner_layers.append(dropout_layer)

        super(ConvolutionLayer, self).__init__(name=name, layers=inner_layers)

        self.config = {
            "filters": filters,
            "kernel_size": kernel_size,
            "dropout_rate": dropout_rate,
            "name": self.name
        }
    #     self.conv2d = conv2d
    #     self.max_pooling = max_pooling
    #     self.batch_normalization = batch_normalization
    #     self.dropout_layer = dropout_layer
    #
    # def call(self, inputs):
    #     x = self.conv2d(inputs)
    #     if self.dropout_layer is not None:
    #         x = self.dropout_layer(x)
    #     x = self.max_pooling(x)
    #     return self.batch_normalization(x)

    def get_config(self):
        config = super(ConvolutionLayer, self).get_config()

        config.update(self.config)
        return config

    @classmethod
    def from_config(cls, config):
        params = ["filters", "kernel_size", "dropout_rate", "trainable", "name"]
        config_filtered = {key: value for key, value in config.items() if key in params}
        return cls(**config_filtered)


class DenseWithNormalization(tf.keras.Sequential):

    def __init__(self, dense, activation, dropout_rate=None, l1_regularizer_rate=None,
                 l2_regularizer_rate=None, trainable=True, name=None):

        if l1_regularizer_rate is not None:
            regularizer = regularizers.l1(l1_regularizer_rate)
        elif l2_regularizer_rate is not None:
            regularizer = regularizers.l2(l2_regularizer_rate)
        else:
            regularizer = None
        dense_layer = layers.Dense(dense, activation=activation, kernel_regularizer=regularizer, trainable=trainable)

        inner_layers = [dense_layer]

        dropout_layer = None
        if dropout_rate is not None:
            dropout_layer = layers.Dropout(dropout_rate, trainable=trainable)
            inner_layers.append(dropout_layer)

        super(DenseWithNormalization, self).__init__(name=name, layers=inner_layers)

        self.config = {
            "dense": dense,
            "activation": activation,
            "dropout_rate": dropout_rate,
            "l1_regularizer_rate": l1_regularizer_rate,
            "l2_regularizer_rate": l2_regularizer_rate,
            "name": self.name
        }
    #     self.dense_layer = dense_layer
    #     self.dropout_layer = dropout_layer
    #
    # def call(self, inputs):
    #     x = self.dense_layer(inputs)
    #     if self.dropout_layer is not None:
    #         x = self.dropout_layer(x)
    #     return x

    def get_config(self):
        config = super(DenseWithNormalization, self).get_config()

        config.update(self.config)
        return config

    @classmethod
    def from_config(cls, config):
        params = ["dense", "activation", "dropout_rate", "l1_regularizer_rate",
                 "l2_regularizer_rate", "trainable", "name"]
        config_filtered = {key: value for key, value in config.items() if key in params}
        return cls(**config_filtered)


def get_model_from_file(filepath):
    json_string = ""
    with open(filepath) as file:
        json_string = file.readlines()
    return tf.keras.models.model_from_json(json_string)
