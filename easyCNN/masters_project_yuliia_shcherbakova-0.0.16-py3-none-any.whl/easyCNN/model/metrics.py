import tensorflow as tf
# import tensorflow_addons as tfa
import numpy as np


class NoDiseasePrecision(tf.keras.metrics.Precision):
    def __init__(self, no_disease_class_id=0, **kwargs):
        kwargs["name"] = "no_disease_precision"
        super(NoDiseasePrecision, self).__init__(**kwargs)
        self.no_disease_class_id = no_disease_class_id

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_pred = tf.math.argmax(y_pred, axis=-1, output_type=tf.dtypes.int32)
        class_id = tf.constant(self.no_disease_class_id)
        y_true_disease_exist = tf.math.equal(y_true, class_id)
        y_pred_disease_exist = tf.math.equal(y_pred, class_id)

        return super(NoDiseasePrecision, self).update_state(y_true_disease_exist, y_pred_disease_exist, sample_weight)


def get_metrics(no_disease_class_id):
    # Can use tf AUC, but then labels need to be transformed into one-hot
    return [NoDiseasePrecision(no_disease_class_id=no_disease_class_id),
            "accuracy"]
            # confusion_matrix_accuracy]


def confusion_matrix_accuracy(y_true, y_pred):
    y_pred = tf.math.argmax(y_pred, axis=1, output_type=tf.dtypes.int32) # Can try using from_logits arg
    confusion_mtx = tf.math.confusion_matrix(y_true, y_pred)
    class_samples = np.sum(confusion_mtx, axis=0) # actual labels are in columns
    predicted_correctly = np.diag(confusion_mtx)
    np.seterr(divide='ignore', invalid='ignore')
    classes_accuracy = predicted_correctly/class_samples
    not_nan = np.invert(np.isnan(classes_accuracy))
    classes_accuracy = classes_accuracy[not_nan]
    prod = np.prod(classes_accuracy)
    return prod

if __name__ == '__main__':
    confusion_matrix_accuracy(tf.constant([2, 2, 2, 1, 1, 2, 2]), tf.constant([0, 1, 2, 1, 0, 2, 2]))
    # v = tfa.metrics.multilabel_confusion_matrix.MultiLabelConfusionMatrix(tf.constant([2, 2, 2, 1, 1, 2, 2]), tf.constant([0, 1, 2, 1, 0, 2, 2]))
    # print(v)
