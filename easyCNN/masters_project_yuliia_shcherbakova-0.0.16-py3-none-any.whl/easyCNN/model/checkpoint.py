import tensorflow as tf
import os

MAX_EPOCHS_WITHOUT_IMPROVE = 5


class SaveModelCheckpoint(tf.keras.callbacks.Callback):

    def __init__(self):
        super(SaveModelCheckpoint, self).__init__()

        self._start_loss = 100000
        self._epochs_without_improvement = 0

    def on_epoch_begin(self, epoch, logs=None):
        if logs.get('loss') is not None:
          self._start_loss = logs['loss']

    def on_epoch_end(self, epoch, logs=None):
        self._safe_model_saving("newest_model_1.h5", f"newest_model.h5")
        if logs['loss'] < self._start_loss:
            self._epochs_without_improvement = 0
        else:
            self._epochs_without_improvement += 1

        if self._epochs_without_improvement >= MAX_EPOCHS_WITHOUT_IMPROVE:
            print(f"Model has stopped training in epoch {epoch} because it wasn't improving for {MAX_EPOCHS_WITHOUT_IMPROVE} epochs."
                  f"Final metrics: {str(logs)}")
            self.model.stop_training = True

    def _safe_model_saving(self, actual_filename, backup_filename):
        if not os.path.exists("checkpoints"):
            os.mkdir("checkpoints")
        backup_path = os.path.join("checkpoints", backup_filename)
        actual_path = os.path.join("checkpoints", actual_filename)

        self.model.save_weights(backup_path)
        if os.path.exists(actual_path):
            os.remove(actual_path)
        os.rename(backup_path, actual_path)


if __name__ == '__main__':
    SaveModelCheckpoint()