import tensorflow as tf
from tensorflow.keras.preprocessing import image
import numpy as np

from ..model.disease_recognition_model import DataAugmentationLayer, ConvolutionLayer, DenseWithNormalization, DiseaseRecognitionModel
from ..model.metrics import NoDiseasePrecision
# from disease_recognition_model import DataAugmentationLayer, ConvolutionLayer, DenseWithNormalization, DiseaseRecognitionModel
# from metrics import NoDiseasePrecision

def predict(h5_file, image_to_predict):
    custom_objects = {"DiseaseRecognitionModel": DiseaseRecognitionModel,
                      "DataAugmentationLayer": DataAugmentationLayer,
                      "ConvolutionLayer": ConvolutionLayer,
                      "DenseWithNormalization": DenseWithNormalization,
                      "NoDiseasePrecision": NoDiseasePrecision}
    with tf.keras.utils.custom_object_scope(custom_objects):
        model = tf.keras.models.load_model(h5_file)

    img_size = model.layers[0].input_shape[1:3]
    img = image.load_img(image_to_predict, target_size=img_size)
    img_array = image.img_to_array(img)
    processed_image = np.expand_dims(img_array, axis=0)

    return model.predict(processed_image)