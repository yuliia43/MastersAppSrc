import tensorflow as tf
import pathlib
import os


def get_datasets(data_zip_path, root_folder_name, img_size, batch_size, val_percent, test_percent=0,
                 distribute_strategy=None):
    img_height, img_width = img_size

    data_dir = tf.keras.utils.get_file(None, origin=data_zip_path, extract=True)
    data_dir = pathlib.Path(data_dir)

    dir_name = os.path.dirname(data_dir)
    data_dir = f"{dir_name}/{root_folder_name}"

    train_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        validation_split=val_percent,
        subset="training",
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size)
    val_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        validation_split=val_percent,
        subset="validation",
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size)

    class_names = train_ds.class_names
    print(f"retrieved dataset wih classes: {','.join(class_names)}")
    no_finding_id = class_names.index("NoFinding")

    AUTOTUNE = tf.data.AUTOTUNE

    # Prefetch set to 1 may reduce memory usage
    train_ds_prefetched = train_ds.cache().shuffle(len(train_ds.file_paths)).repeat().prefetch(buffer_size=AUTOTUNE)
    val_ds_prefetched = val_ds.cache().shuffle(len(val_ds.file_paths)).repeat().prefetch(buffer_size=AUTOTUNE)

    # We need to create specific distributed dataset for distributed learning
    if distribute_strategy is not None:
        train_ds_prefetched = distribute_strategy.experimental_distribute_dataset(train_ds_prefetched)
        val_ds_prefetched = distribute_strategy.experimental_distribute_dataset(val_ds_prefetched)


    return train_ds_prefetched, val_ds_prefetched, no_finding_id, class_names