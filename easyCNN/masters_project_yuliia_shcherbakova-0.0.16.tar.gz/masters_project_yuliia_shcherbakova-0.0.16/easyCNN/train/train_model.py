import json
import os.path

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

import csv
import seaborn as sns

# from disease_recognition_model import DataAugmentationLayer, ConvolutionLayer, DenseWithNormalization
# from easyCNN import DiseaseRecognitionModel, get_metrics, SaveModelCheckpoint
# from dataset import get_datasets
# from predict import predict
# from tensorflow.keras.preprocessing import image


def train(train_ds, val_ds, model, optimizer, loss, metrics, callbacks, epochs, steps_per_epoch=100, validation_steps=50,
          csv_model_file=None, class_names=None, mid=1):
    training_metafile = f"meta_{mid}.json"

    meta = {
        "optimizer": optimizer.__class__.__name__ if not isinstance(optimizer, str) else optimizer,
        "learning_rate": str(optimizer.learning_rate.numpy()) if not isinstance(optimizer, str) else "default",
        "loss": loss.__class__.__name__ if not isinstance(loss, str) else loss,
        "metrics": [metric.__class__.__name__ if not isinstance(metric, str) else metric for metric in metrics],
        "callbacks": [callback.__class__.__name__ for callback in callbacks],
        "epochs": epochs,
        "steps_per_epoch": steps_per_epoch,
        "validation_steps": validation_steps
    }
    if not isinstance(train_ds, tf.distribute.DistributedDataset):
        meta["image_size"] =  train_ds.element_spec[0].shape[1:-1].as_list()
    with open(training_metafile, "w") as jsonfile:
        jsonfile.write(json.dumps(meta))

    model.compile(optimizer=optimizer,
                  loss=loss,
                  metrics=metrics)
    # run_eagerly=True may be needed in compile
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=callbacks,
        steps_per_epoch=steps_per_epoch,
        validation_steps=validation_steps
    )

    if csv_model_file is not None:
        json_model_filename = f"model_{mid}.json"
        model.save_model_into_file(json_model_filename)
        weights_filename = f"model_{mid}.h5"
        model.save(weights_filename)

        model_metrics = {metric.name: metric.result() for metric in model.metrics}
        small_val_ds = val_ds.take(100)
        if class_names:
            x_true = np.concatenate([x for x, y in small_val_ds], axis=0)
            y_true = np.concatenate([y for x, y in small_val_ds], axis=0)

            y_pred = np.argmax(model.predict(x_true), axis=1)

            _create_plots(epochs, history, y_pred, y_true, class_names)
        else:
            _create_plots(epochs, history)

        train_plots_filename = f"model_train_graphics_{mid}.pdf"
        plt.savefig(train_plots_filename)

        with open(csv_model_file, "a+") as model_stats:
            fieldnames = ['json_model', 'plots_filename', 'weights', 'training_metadata', *model_metrics.keys()]
            writer = csv.DictWriter(model_stats, fieldnames=fieldnames)
            model_metrics.update({'json_model': json_model_filename,
                            'plots_filename': train_plots_filename,
                            'weights': weights_filename,
                            'training_metadata': training_metafile})
            if mid == 1:
                writer.writeheader()
            writer.writerow(model_metrics)

    # at the end write model into json, save training plot into pdf,
    # add link into .csv with best model loss & metrics


def _create_plots(epochs, history, y_pred=None, y_true=None, classes=None):
    graphs_count = 3
    graphs_start_id = 1
    if y_pred is not None and y_true is not None and classes is not None:
        graphs_count += 1
        fig, (ax1, ax2, ax3, ax4) = plt.subplots(graphs_count, 1, figsize=(20, 40))
        confusion_mtx = tf.math.confusion_matrix(y_true, y_pred)
        heatmap = sns.heatmap(confusion_mtx,
                              xticklabels=classes,
                              yticklabels=classes,
                              annot=True, fmt='g', ax=ax1)
        heatmap.set_xlabel('Prediction')
        heatmap.set_ylabel('Label')
        ax1.title.set_text("Confusion Matrix")
        graphs_start_id = 2
    else:
        plt.figure(figsize=(20, 40))
    train_loss = history.history['loss']
    val_loss = history.history['val_loss']
    train_precision = history.history['no_disease_precision']
    val_precision = history.history['val_no_disease_precision']
    matrix = history.history["accuracy"]
    val_matrix = history.history["val_accuracy"]
    xc = range(epochs)
    plt.subplot(graphs_count, 1, graphs_start_id)
    train_loss_line, = plt.plot(xc, train_loss, label="Training loss")
    val_loss_line, = plt.plot(xc, val_loss, label="Validation loss")
    plt.legend(handles=[train_loss_line, val_loss_line])
    plt.title("Loss")
    plt.subplot(graphs_count, 1, graphs_start_id+1)
    train_precision_line, = plt.plot(xc, train_precision, label="Training NoDisease precision")
    val_precision_line, = plt.plot(xc, val_precision, label="Validation NoDisease precision")
    plt.legend(handles=[train_precision_line, val_precision_line])
    plt.title("NoDisease precision")
    plt.subplot(graphs_count, 1, graphs_start_id+2)
    matrix_line, = plt.plot(xc, matrix, label="Training accuracy")
    val_matrix_line, = plt.plot(xc, val_matrix, label="Validation accuracy")
    plt.legend(handles=[matrix_line, val_matrix_line])
    plt.title("Accuracy")

# if __name__ == '__main__':
#     img_size = (200, 200)
#     batch_size = 128
#     epochs = 1
#
#     loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
#     train_ds, val_ds, no_finding_id, class_names = get_datasets("file:///E:/x-ray_dataset.tar", "dataset", img_size,
#         batch_size, 0.2, distribute_strategy=tf.distribute.experimental.MultiWorkerMirroredStrategy())
#     metrics = get_metrics(no_finding_id)
#     model_parameters = {
#         'img_height': img_size[0],
#         'img_width': img_size[1],
#         'cnn_args': [(1, 3, 0.2)],
#         'dense_args': [(1, "relu", 0.8, None, 0.001)],
#         # 'cnn_args': [(128, 3, None), (64, 3, None), (16, 3, None), (8, 3, 0.2)],
#         # 'dense_args': [(64, "relu", None, None, 0.001), (32, "relu", 0.8, None, 0.001)],
#         'num_classes': len(class_names),
#     }
#     model = DiseaseRecognitionModel(**model_parameters)
#     train(train_ds, val_ds, model, tf.keras.optimizers.Adam(learning_rate=0.00125), loss, metrics, [SaveModelCheckpoint()], epochs,
#           csv_model_file="model_comparison.csv", class_names=class_names)
#     res = predict("model_1.h5", "test_image.png")
#     res
